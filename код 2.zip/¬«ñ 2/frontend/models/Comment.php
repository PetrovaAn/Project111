<?php

namespace frontend\models;

use yii\db\ActiveRecord;
use yii\db\BaseActiveRecord;

/**
 * This is the model class for table "gosteh_cars".
 *
 * @property int $id
 * @property string $brand [varchar(255)]
 * @property string $model [varchar(255)]
 * @property string $vin [varchar(255)]
 * @property string $registration_number [varchar(255)]
 * @property int $taxi [int(11)]
 * @property int $type [int(11)]
 * @property int $client_id [int(11)]
 * @property int $last_to [int(11)]
 * @property int $created_at
 * @property int $updated_at
 * @property int $deleted_at
 */

class Comment extends ActiveRecord
{

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'timestamp' => [
                'class' => 'yii\behaviors\TimestampBehavior',
                'attributes' => [
                    BaseActiveRecord::EVENT_BEFORE_INSERT => ['created_at'],
                    BaseActiveRecord::EVENT_BEFORE_UPDATE => ['updated_at'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'comment';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['text','username','news_id'], 'required'],
            [['text','username'], 'string'],
            [['created_at','updated_at','deleted_at','news_id'],'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'username' => 'Имя',
            'text' => 'Комментарий',
            'last_to' => 'Дата последнего ТО',
            'created_at' => 'Дата создания',
            'updated_at' => 'Дата редактирования',
            'deleted_at' => 'Дата удаления',
        ];
    }
}